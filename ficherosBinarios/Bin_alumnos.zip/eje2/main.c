#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funciones.h"

int main(int argc, char **argv)
{
    if (argc!=2)
    {
        printf("Error, introduzca el nombre del fichero bin\n");
        exit(-1);
    }
    char *nF=argv[1];

    struct alumno a;

//Añadir
    int na; //numero alumnos
    struct alumno add;
    printf("Introduzca el numero de alumnos que quiera agregar\n");
    scanf("%d", &na);
    for (int i = 0; i < na; i++)
    {
        printf("Introduzca el DNI del alumno\n");
        scanf("%s", add.dni);
        printf("Introduzca el curso del alumno\n");
        scanf("%d", &add.curso);
        printf("Introduzca la nota del alumno\n");
        scanf("%f", &add.nota);

        addA(nF, add);
    }

//mostrar fichero
    mostrarFich(nF);

//contar registros
    int tam=contarAlumnos(nF);
    printf("Hay un total de %d alumnos\n", tam);

//Reserva memoria
    struct alumno *v=NULL;
    v=reservaMem(tam);

//fichero a vector
    fichero_a_vector(nF, v);

//mostrar vector
    mostrarVector(v, tam);

//modifica nota del alumno
    char dni[10];
    float nota;
    printf("Introduzca el DNI del alumno con nota a modificar\n");
    scanf("%s", dni);
    printf("Introduzca la nueva nota\n");
    scanf("%f", &nota);
    
    modificaNota(nF, dni, nota);
    mostrarFich(nF);

//Dividir en dos ficheros
    ficheros(nF);

//libera memoria
    liberaMemV(&v);    
    return 0;
}
