#ifndef FUNCIONES_H
#define FUNCIONES_H

struct alumno
{
    char dni[10];
    int curso;
    float nota;
};
void addA(char *nF, struct alumno add);
void mostrarFich(char *nF);
int contarAlumnos(char *nF);
void fichero_a_vector(char *nF, struct alumno *v);
struct alumno *reservaMem(int tam);
void liberaMemV(struct alumno **v);
void mostrarVector(struct alumno *v, int tam);
void modificaNota(char *nF, char *dni, float nota);
void ficheros(char *nF);
/*
Tarea:

-añade alumno al fichero
-mostrar fichero
-contar registros
-fichero a vector
-mostrar vector
-modifica nota de alumno por dni
-divide los alumnos del fichero en aprobados.bin y suspensos.txt

hacer el pdf de angel antes del lunes, el de alumnos nota
*/

#endif