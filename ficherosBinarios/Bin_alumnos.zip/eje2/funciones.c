#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funciones.h"

void addA(char *nF, struct alumno add)
{
    FILE *fich=fopen(nF, "ab");
    if (fich==NULL)
    {
        printf("Error\n");
        exit(-1);
    }
    fwrite(&add, sizeof(struct alumno), 1, fich);
    fclose(fich);
}
void mostrarFich(char *nF)
{
    FILE *fich=fopen(nF, "rb");
    if (fich==NULL)
    {
        printf("Error\n");
        exit(-1);
    }

    struct alumno a;
    while (fread(&a, sizeof(struct alumno), 1, fich)==1)
    {
        printf("DNI: %s\n", a.dni);
        printf("CURSO: %d\n", a.curso);
        printf("NOTA: %f\n", a.nota);
    }
    fclose(fich);
}
int contarAlumnos(char *nF)
{
    FILE *fich=fopen(nF, "rb");
    if (fich==NULL)
    {
        printf("Error\n");
        exit(-1);
    }

    fseek(fich, 0, SEEK_END);
    double nbytes=ftell(fich);
    int tam=nbytes/sizeof(struct alumno);

    fclose(fich);
    return tam;
}
void fichero_a_vector(char *nF, struct alumno *v)
{
    FILE *fich=fopen(nF, "rb");
    if (fich==NULL)
    {
        printf("Error\n");
        exit(-1);
    }
    int i=0;
    struct alumno a;
    while (fread(&a, sizeof(struct alumno), 1, fich)==1)
    {
        v[i]=a;
        i++;
    }
    fclose(fich);
}
struct alumno *reservaMem(int tam)
{
    struct alumno *v=NULL;
    v=(struct alumno*)malloc(sizeof(struct alumno)*tam);
    if (v==NULL)
    {
        printf("Error\n");
        exit(-1);
    }
    return v;
}
void liberaMemV(struct alumno **v)
{
    free(*v);
    (*v)=NULL;
}
void mostrarVector(struct alumno *v, int tam)
{
    for (int i = 0; i < tam; i++)
    {
        printf("---> %s\n", v[i].dni);
        printf("---> %d\n", v[i].curso);
        printf("---> %f\n", v[i].nota);
    }
}
void modificaNota(char *nF, char *dni, float nota)
{
    FILE *fich=fopen(nF, "rb+");
    if (fich==NULL)
    {
        printf("Error\n");
        exit(-1);
    }
    struct alumno a;
    while (fread(&a, sizeof(struct alumno), 1, fich)==1)
    {
        if (strcmp(dni, a.dni)==0)
        {
            a.nota=nota;
            fseek(fich, -1*sizeof(struct alumno), SEEK_CUR);
            fwrite(&a, sizeof(struct alumno), 1, fich);
        }
    }
    fclose(fich);
}
void ficheros(char *nF)
{
    FILE *fich=fopen(nF, "rb");
    if (fich==NULL)
    {
        printf("Error\n");
        exit(-1);
    }
    FILE *fich1=fopen("aprobados.bin","wb");
    if (fich1==NULL)
    {
        printf("Error\n");
        fclose(fich);
        exit(-1);
    }
    FILE *fich2=fopen("suspensos.txt", "w");
    if (fich2==NULL)
    {
        printf("Error\n");
        fclose(fich);
        fclose(fich1);
        exit(-1);
    }
    struct alumno a;
    while (fread(&a, sizeof(struct alumno), 1, fich)==1)
    {
        if (a.nota>=5)
        {
            fwrite(&a, sizeof(struct alumno), 1, fich1);
        }
        else if(a.nota<5)
        {
            fprintf(fich2, "DNI: %s\nCURSO: %d\nNOTA: %f\n", a.dni, a.curso, a.nota);
        }
    }
    fclose(fich);
    fclose(fich1);
    fclose(fich2);
}